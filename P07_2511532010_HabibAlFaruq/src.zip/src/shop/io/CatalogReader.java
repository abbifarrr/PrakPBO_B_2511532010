package shop.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import shop.model.Product;
import shop.model.PhysicalProduct;
import shop.exception.CatalogLoadException;

public class CatalogReader {
    private static final Logger LOG = Logger.getLogger(CatalogReader.class.getName());
    private int skippedCount;

    public List<Product> load(Path file) throws CatalogLoadException {
        List<Product> products = new ArrayList<>();
        skippedCount = 0;
        
        // 1. Buka file memakai Try-With-Resources (tutup otomatis walau error)
        try (BufferedReader reader = Files.newBufferedReader(file)) {
            String line;
            int lineNumber = 0;
            
            // 2. Baca baris per baris
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                
                // 3. Tangani masing-masing baris yang rusak tanpa merusak seluruh iterasi
                try {
                    Product parsedProduct = parse(line);
                    products.add(parsedProduct);
                } catch (IllegalArgumentException e) {
                    skippedCount++;
                    LOG.warning("Baris " + lineNumber + " dilewati: " + e.getMessage());
                    continue; // lanjut baris berikutnya
                }
            }
        } catch (IOException e) {
            // 4. Jika file tidak ditemukan atau masalah I/O lainnya
            throw new CatalogLoadException("Katalog gagal dibaca: " + file, e);
        }
        
        return products;
    }
    
    private Product parse(String line) {
        String[] parts = line.split(";");
        if (parts.length != 4) {
            throw new IllegalArgumentException("expected 4 fields, found " + parts.length);
        }
        String sku = parts[0];
        String name = parts[1];
        long price = Long.parseLong(parts[2]);
        int weight = Integer.parseInt(parts[3]);
        return new PhysicalProduct(sku, name, price, weight);
    }
    
    public int getSkippedCount() {
        return skippedCount;
    }
}