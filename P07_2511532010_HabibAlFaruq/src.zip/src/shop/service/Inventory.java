package shop.service;

import java.util.HashMap;
import java.util.Map;
import shop.exception.OutOfStockException;

public class Inventory {
    private final Map<String, Integer> stocks = new HashMap<>();

    public void addStock(String sku, int qty) {
        if (qty <= 0) throw new IllegalArgumentException("Quantity must be positive");
        stocks.put(sku, available(sku) + qty);
    }

    public int available(String sku) {
        return stocks.getOrDefault(sku, 0);
    }

    // TODO: reserve
    public void reserve(String sku, int qty) throws OutOfStockException {
        if (qty <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        int currentStock = available(sku);
        if (qty > currentStock) {
            throw new OutOfStockException(sku, qty, currentStock);
        }
        stocks.put(sku, currentStock - qty);
    }

    // TODO: release
    public void release(String sku, int qty) {
        if (qty <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        int currentStock = available(sku);
        stocks.put(sku, currentStock + qty);
    }
}