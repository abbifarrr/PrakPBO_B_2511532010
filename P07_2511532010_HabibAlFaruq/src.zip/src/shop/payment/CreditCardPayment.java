package shop.payment;

import shop.exception.InsufficientBalanceException;

public class CreditCardPayment implements RefundablePayment, InstallmentPayment {
    private final String cardHolder;
    private final long creditLimit;
    private long usedCredit;

    public CreditCardPayment(String cardHolder, long creditLimit) {
        if (cardHolder == null || cardHolder.isBlank()) throw new IllegalArgumentException("Blank holder");
        if (creditLimit < 0) throw new IllegalArgumentException("Negative limit");
        this.cardHolder = cardHolder;
        this.creditLimit = creditLimit;
        this.usedCredit = 0;
    }

    @Override
    public String getName() {
        return "Kartu Kredit (" + cardHolder + ")";
    }

    @Override
    public void pay(long amount) throws InsufficientBalanceException {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        long availableLimit = creditLimit - usedCredit;
        if (amount > availableLimit) {
            throw new InsufficientBalanceException(amount, availableLimit);
        }
        usedCredit += amount;
    }

    @Override
    public boolean refund(long amount) {
        if (amount <= 0 || amount > usedCredit) return false;
        usedCredit -= amount;
        return true;
    }

    @Override
    public int maxInstallmentMonths() {
        return 12;
    }

    public long getUsedCredit() {
        return usedCredit;
    }
}