package shop.payment;

import shop.exception.PaymentFailedException;

public class BankTransferPayment implements PaymentMethod {
    private final String bankName;
    private boolean online = true; // Simulasi sistem

    public BankTransferPayment(String bankName) {
        if (bankName == null || bankName.isBlank()) throw new IllegalArgumentException("Bank name required");
        this.bankName = bankName;
    }

    @Override
    public String getName() {
        return "Transfer " + bankName;
    }

    @Override
    public void pay(long amount) throws PaymentFailedException {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        if (!online) {
            throw new PaymentFailedException(bankName + " sedang gangguan, coba lagi nanti");
        }
    }
    
    // Method simulasi untuk men-trigger error di skenario 2
    public void setOnline(boolean status) {
        this.online = status;
    }
}